from django.apps import AppConfig


class ApptiendainventarioConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'appTiendaInventario'
